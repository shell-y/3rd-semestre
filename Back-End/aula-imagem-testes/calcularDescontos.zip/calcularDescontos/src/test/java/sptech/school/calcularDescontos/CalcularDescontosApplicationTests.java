package sptech.school.calcularDescontos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalcularDescontosApplicationTests {

	@Test
	void contextLoads() {
	}

}
