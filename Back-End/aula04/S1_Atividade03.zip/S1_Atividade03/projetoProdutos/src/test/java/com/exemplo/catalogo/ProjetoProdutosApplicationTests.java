package com.exemplo.catalogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
