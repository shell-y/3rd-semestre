package sptech.school.atividadeBoleto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeBoletoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeBoletoApplication.class, args);
	}

}
