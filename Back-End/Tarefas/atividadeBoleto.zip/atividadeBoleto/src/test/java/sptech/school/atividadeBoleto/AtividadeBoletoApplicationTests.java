package sptech.school.atividadeBoleto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeBoletoApplicationTests {

	@Test
	void contextLoads() {
	}

}
